Thanks for downloading the graphic resource from GraphicsFuel.com. 

TERMS OF USAGE:

* You can use the artworks for your personal or client�s work. However, you should not use it for multiple people or as a print piece (e.g. t-shirts, brochures, CD covers, etc) aimed at distribution / sale. (If you want to use my artworks for a printed distributive / sale piece, you need to purchase a license from me.) You can use my artwork for your PERSONAL print stuff.

* You can use my artworks in your websites, logos, greeting cards, online brochures, documents. I request you to add a link back to the relevant webpage of GraphicsFuel.com.

* You can use the files while creating your own designs as a learning experience.

* You should not host the downloaded source files on your server and redistribute as your own either in part or whole. If you want to share the files, you can link back to the original source page or location of GraphicsFuel.

* You should not sell / redistribute the files in part or whole on your site or any stock photography or vector site including offline or online.

* You should not use the files to promote pornography, SPAM, illegal business, crime, alcohol, gambling, racial or sexual activities.

* You are not permissited to distribute / redistribute the resources available on GraphicsFuel.com without prior written permission. 

______________________________

http://www.graphicsfuel.com/

Subscribe to GraphicsFuel at: http://feeds.feedburner.com/GraphicsFuel 



